/*

  XORDER.CGI 0.74
  (C) Copyright by Joe Forster/STA, 2000-2005


  License:

    This software is available free of charge. Please, do whatever useful you
    can do with it. If you like, contact the original author at sta@c64.org.
    You may not sell this software, its source code or any derivatives for
    money but you may make money using it.


  Programming notes:

    This software uses fixed-point numbers rather than floating-point numbers
    for prices, conversion rates and all other non-integer numbers. The
    fixed-point numbers are implemented as rational numbers with a denominator
    of a power of ten. To be able to divide rational numbers, the compiler has
    to be capable of handling 64-bit integers (long long int). Be warned, you
    may still have problems with very small or very large numbers.


  Revision history:

    0.10       Initial release

    0.20  Mod: At shipping prices, when trying to find a shipping price with
               an appropriate <Max total order value> then the current
               shipping price is also added to total order value.
          New: All prices can contain fractions rather than being integers
               only.

    0.21  New: The copyright string at the bottom of the generated page links
               to a page where the script lists its own source and config
               file.

    0.22  Fix: Fixed division problems with low (less than one) but precise
               (five or more decimal places) currency conversion rates.

    0.23  New: A "(This page best viewed with any browser)" banner is added to
               the bottom of generated pages.

    0.24  Mod: Spaces are allowed before and after equation marks and commas.
          New: You can define a default subject for generated order E-mails.

    0.30  Mod: More than one paper money can be defined for each currency, for
               the purpose of rounding up prices. This is important if the
               smallest paper money is not a divisor of the others.

    0.31  Mod: When using the cash pay method, not only the rounded up
               converted prices are displayed but also the original ones.
          New: You can define a title for generated order detail pages.
          Src: Created a make file for easy compilation.

    0.32  Src: Wrote down in the make file how to convert leading spaces to
               true Tab characters.

    0.33  Mod: Removed the postal check pay method. All code related to pay
               methods is still there so you can define your own ones, if you
               like.

    0.40  Mod: Put back the postal check pay method, along with a credit card
               pay method.
          New: If the original total price is converted to other currencies,
               the user can select the preferred total price from a list.

    0.50  New: Added complete support for three more payment methods: checks,
               money orders and credit cards.
          New: Payment method is displayed in the order details, under the
               personal data.

    0.60  Mod: Payment information is not displayed on generated pages.
               Confirmation E-mails should contain this instead.

    0.61  Mod: Added the bank transfer payment method.

    0.62  Mod: Instead of a fixed value, the weight of the envelope is now a
               given as a percentage of the total weight of the products
               contained in it.

    0.63  Mod: Generated pages mention that the order travels via an E-mail.

    0.64  Fix: Fixed a problem with converted total prices not being
               displayed in certain cases.

    0.65  Fix: An extra shipping option, appearing more than once in the
               input, generates an error message.

    0.66  New: Added a new configuration option that specifies additional
               conversion costs for different payment methods.

    0.67  Fix: The total weight of the package is checked, for possibly too
               large packages, after having added the weight of the envelope
               rather than before that.

    0.68  New: At the bottom of generated pages, the customer is told to wait
               for a few days for the confirmation mail.

    0.70  Mod: The maximum number of products, shipping prices and currencies
               defined in the configuration is not a constant, burnt into the
               software, rather a value in the configuration file itself.

    0.71  New: The field showing the order details is now read-only. Works
               only in browsers that support the READONLY tag.

    0.72  New: Added support for important notes in the configuration file.

    0.73  Mod: Changed the alignment of all paragraphs to justified.

    0.74  Mod: Allowed lines in the configuration file to end with the DOS-
               style CR+LF mark, as well.
          Add: Added some text to the order details page about how orders are
               being submitted, how to solve possible submitting problems, and
               how fast confirmation E-mails should be expected.
          Src: Put MAXLONG into an #ifdef block so that it is not re-defined
               if already defined by a header file of the C compiler package.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <values.h>

/* Boolean type */
#define bool unsigned short int
#define false (0 == 1)
#define true (0 == 0)
/* String type */
#define string char*
/* Maximum value for long integers */
#ifndef MAXLONG
  #define MAXLONG 0x7FFFFFFFL
#endif

/* Maximum length of strings */
#define ItemNameMaxLen 20
#define ItemValueMaxLen 1000
#define FileNameMaxLen 200
#define RawDataMaxLen 5000
/* Maximum number of data defined in configuration */
#define MaxGeneralNum 15
/* Maximum number of items defined in input form */
#define MaxItemNum 50
/* Maximum number of paper money per currency */
#define MaxPaperMoneyNum 5
/* Number of defined type names */
#define SectionNameNum 6
#define ShippingDestNameNum 2
#define PayMethodNum 5
#define ItemTypeNameNum 4
/* Number of decimal places for cents */
#define CentsFractionLen 2
/* Radix for the denominator of rational numbers */
#define Radix 10
/* Maximum possible exponent of the radix for long long integers */
#define MaxLongLongExp 13

/* Section modes */
#define smGeneral 0
#define smProducts 1
#define smShippingInland 2
#define smShippingWorldwide 3
#define smPayMethodCosts 4
#define smCurrencyConversion 5
/* Shipping price types */
#define stNormal 0
#define stOption 1
#define stOptionAt 2
/* Shipping destination */
#define sdInland 0
#define sdWorldwide 1
/* Paying methods */
#define pmCash 0
#define pmCheck 1
#define pmMoneyOrder 2
#define pmCreditCard 3
#define pmBankTransfer 4
/* Form item types */
#define itPersonal 0
#define itProduct 1
#define itShipping 2
#define itCurrency 3
/* Return codes */
#define rcOK 0
#define rcInternalError 1
#define rcMissingInputData 2
#define rcInvalidInputData 3
#define rcEmptyOrder 4
#define rcExcessOrder 5

/* Command line parameters */
#define clListSelf "listself"
/* Software name */
#define SoftwareName "XORDER.CGI"
/* Software version number */
#define SoftwareVersion "0.74"
/* Software copyright */
#define SoftwareCopyright "(&copy; by Joe Forster/STA, 2000-2005)"
#define Yes "Yes"

/* Directory separator character */
#define DirSep '/'
/* Separator string */
string SeparatorStr =
  "--------------------  ---  --------  -----------  ------  ------------";
/* Section names */
string SectionNames[SectionNameNum] =
{
  "General",
  "Products",
  "Shipping inland",
  "Shipping worldwide",
  "Payment costs",
  "Currency conversion"
};
/* Item type names */
string ItemTypeNames[ItemTypeNameNum] =
{
  "Personal",
  "Product",
  "Shipping",
  "Currency"
};
/* Shipping destination names */
string ShippingDestNames[ShippingDestNameNum] =
{
  "Inland",
  "Worldwide"
};
/* Payment method names */
string PayMethodNames[PayMethodNum] =
{
  "Cash",
  "Check",
  "Money order",
  "Credit card",
  "Bank transfer",
};

/* Rational number */
typedef struct
{
  long int Numerator;
  long int Denominator;
} Rational;
/* General data */
typedef struct
{
  char Name[ItemNameMaxLen + 1];
  char Value[ItemValueMaxLen + 1];
} General;
/* Product */
typedef struct
{
  char Name[ItemValueMaxLen + 1];
  Rational Price;
  long int Weight;
  bool AlwaysOnStock;
} Product;
/* Shipping price */
typedef struct
{
  char Name[ItemValueMaxLen + 1];
  int Destination;
  Rational Price;
  long int MaxWeight;
  long int A_Weight;
  Rational MaxValue;
  bool Processed;
} Shipping;
/* Currency */
typedef struct
{
  char Name[ItemValueMaxLen + 1];
  int PaperMoneyNum;
  Rational Rate;
  Rational PaperMoneys[MaxPaperMoneyNum];
} Currency;
/* Form item */
typedef struct
{
  int Type;
  string Name;
  string Value;
} Item;
/* Payment method costs */
typedef struct
{
  int Type;
  Rational Unit;
  Rational Cost;
} PayMethodCost;

bool ListingSelf;
int MaxProductNum;
int MaxShippingNum;
int MaxCurrencyNum;
int GeneralNum;
int ProductNum;
int ShippingNum;
int CurrencyNum;
int PayMethodCostNum;
int ItemNum;
int ShippingDest;
int BoxHeight;
int FractionLen;
long int TotalWeight;
string ProgName;
string NextRawData;
string ItemData;
string ItemName;
string ItemValue;
string BoxHeightStr;
char InputData[RawDataMaxLen + 1];
char OutputData[RawDataMaxLen + 1];
char ErrorItem[ItemValueMaxLen + 1];
Rational TotalPrice;
General GeneralData[MaxGeneralNum];
Product *Products;
Shipping *Shippings;
PayMethodCost PayMethodCosts[PayMethodNum];
Currency *Currencies;
Item Items[MaxItemNum];

/* Get a pointer to the end of a string
   Input : pointer to the beginning of the string
   Output: pointer to the end of the string */
string strend(string String)
{
  return(&String[strlen(String)]);
}

/* Copy a string to another string, stripping off leading and trailing spaces
   Input : Dest: the string to contain the result
           Src: the original string */
void strcpyAllTrim(string Dest, string Src)
{
  string StrEnd;
  while (*Src == ' ') Src++;
  strcpy(Dest, Src);
  StrEnd = strend(Dest);
  if (StrEnd != Dest)
    while ((--StrEnd != Dest) && (*StrEnd == ' ')) *StrEnd = '\0';
}

/* Split a full path into directory, filename and extension
   Input: Path: the full path
          Dir: the string to hold the directory
          Name: the string to hold the filename
          Ext: the string to hold the extension */
void FSplit(const string Path, string Dir, string Name, string Ext)
{
  char TempPath[FileNameMaxLen];
  string TempDir = NULL;
  string TempName = NULL;
  string TempExt = NULL;
  strcpy(TempPath, Path);
  if ((TempName = strrchr(TempPath, DirSep)) == NULL)
    TempName = TempPath;
  else
  {
    TempDir = TempPath;
    *TempName = '\0';
    TempName++;
  }
  if ((TempName != NULL) && (TempExt = (string)strrchr(TempName, '.')) != NULL)
  {
    *TempExt = '\0';
    TempExt++;
  }
  if (Dir != NULL)
  {
    if (TempDir == NULL)
      Dir[0] = '\0';
    else
      strcpy(Dir, TempPath);
  }
  if (Name != NULL)
  {
    if (TempName == NULL)
      Name[0] = '\0';
    else
      strcpy(Name, TempName);
  }
  if (Ext != NULL)
  {
    if (TempExt == NULL)
      Ext[0] = '\0';
    else
      strcpy(Ext, TempExt);
  }
}

/* Merge a directory, a filename and an extension into a full path
   Input : Path: the string to hold the full path
           Dir: the directory
           Name: the filename
           Ext: the extension */
void FMerge(string Path, const string Dir, const string Name, const string Ext)
{
  int Len;
  Path[0] = '\0';
  if (Dir != NULL)
  {
    strcpy(Path, Dir);
    Len = strlen(Path);
    if ((Len > 0) && (Path[Len - 1] != DirSep))
    {
      Path[Len] = DirSep;
      Path[Len + 1] = '\0';
    }
  }
  if (Name != NULL)
    strcat(Path, Name);
  if (Ext != NULL)
  {
    if ((Ext[0] != '\0') && (Ext[0] != '.'))
    {
      Len = strlen(Path);
      Path[Len] = '.';
      Path[Len + 1] = '\0';
    }
    strcat(Path, Ext);
  }
}

/* Change the extension of a filename
   Input : Result: the string to hold the result
           Name: the original filename
           Ext: the new extension */
void MakeExtension(string Result, const string Name, const string Ext)
{
  char TempDir[FileNameMaxLen];
  char TempName[FileNameMaxLen];
  FSplit(Name, TempDir, TempName, NULL);
  FMerge(Result, TempDir, TempName, Ext);
}

/* Create a rational number with a given integer value
   Input : Result: the rational number to hold the result
           Integer: the integer value */
void MakeRational(Rational* Result, const long int Integer)
{
  Result->Numerator = Integer;
  Result->Denominator = 1;
}

/* Normalize two rational numbers by raising their denominator to the same
   power of the radix
   Input: Num1, Num2: the rational numbers */
void NormalizeRationals(Rational* Num1, Rational* Num2)
{
  while (Num1->Denominator < Num2->Denominator)
  {
    Num1->Numerator *= Radix;
    Num1->Denominator *= Radix;
  }
  while (Num2->Denominator < Num1->Denominator)
  {
    Num2->Numerator *= Radix;
    Num2->Denominator *= Radix;
  }
}

/* Add two rational numbers that both have a denominator of a power of the
   radix
   Input : Result: the rational number to hold the result
           Num1, Num2: the two rational numbers to add together */
void AddRational(Rational* Result, const Rational* Num1, const Rational* Num2)
{
  Rational TempNum1 = *Num1;
  Rational TempNum2 = *Num2;
  NormalizeRationals(&TempNum1, &TempNum2);
  Result->Numerator = TempNum1.Numerator + TempNum2.Numerator;
  Result->Denominator = TempNum1.Denominator;
}

/* Divide two rational numbers and convert the result to a rational number
   with a denominator of a power of the radix
   Input : Result: the rational number to hold the result
           Dividend: the rational number to divide
           Divisor: the rational number to divide with */
void DivideRational(Rational* Result, const Rational* Dividend,
  const Rational* Divisor)
{
  long int Numerator;
  long int Denominator;
  long int TempNum;
  long int TempDenom;
  int TempExp = 1;
  long int RadixPower = 1;
  Numerator = Dividend->Numerator * Divisor->Denominator;
  Denominator = Dividend->Denominator * Divisor->Numerator;
  TempNum = Numerator;
  while (TempNum > 0)
  {
    TempNum /= Radix;
    TempExp++;
  }
  TempDenom = Denominator;
  while (TempDenom > 0)
  {
    TempDenom /= Radix;
    RadixPower *= Radix;
    TempExp++;
  }
  while (TempExp > MaxLongLongExp)
  {
    RadixPower /= Radix;
    TempExp--;
  }
  Result->Numerator = ((long long int)Numerator * RadixPower +
    (Denominator >> 1)) / Denominator;
  Result->Denominator = RadixPower;
}

/* Multiply a rational number with an integer
   Input : Result: the rational number to hold the result
           Multipliend: the rational number to multiply
           Multiplier: the integer to multiply with */
void MultiplyRationalInt(Rational* Result, const Rational* Multipliend,
  const long int Multiplier)
{
  Result->Numerator = Multipliend->Numerator * Multiplier;
  Result->Denominator = Multipliend->Denominator;
}

/* Determine the sign of a rational number
   Input : Num: the rational number
   Output: the sign of the rational number: 0 for zero; -1 for negative; +1
           for positive */
int SignRational(const Rational* Num)
{
  if (Num->Numerator == 0)
    return(0);
  else if (Num->Numerator > 0)
    return(1);
  else return(-1);
}

/* Compare two rational numbers that both have a denominator of a power of
   the radix
   Input : Num1, Num2: the two rational numbers to compare
   Output: 0 for equal; -1 for Num1 smaller than Num2; +1 for Num1 greater
           than Num2 */
int CompareRational(const Rational* Num1, const Rational* Num2)
{
  Rational TempNum1 = *Num1;
  Rational TempNum2 = *Num2;
  NormalizeRationals(&TempNum1, &TempNum2);
  if (TempNum1.Numerator == TempNum2.Numerator)
    return(0);
  else if (TempNum1.Numerator > TempNum2.Numerator)
    return(1);
  else return(-1);
}

/* Round up a rational number to the smallest linear combination of some
   rational numbers, if all have a denominator of a power of the radix
   Input : Num: the rational number to round up
           RoundUps: the rational numbers to round up with
           RoundUpNum: the number of round up numbers */
void RoundUpRational(Rational* Num, Rational* RoundUps, const int RoundUpNum)
{
  int Index;
  long int TempNum;
  long int Remainder;
  long int Count;
  long int Product;
  long int Sum;
  long int Min;
  long int* Counts;
  if (RoundUpNum > 0)
  {
    Counts = calloc(RoundUpNum, sizeof(long int));
    for (Index = 0; Index < RoundUpNum; Index++)
      NormalizeRationals(Num, &RoundUps[Index]);
    Index = RoundUpNum - 1;
    TempNum = Num->Numerator;
    Sum = 0;
    Remainder = TempNum;
    Min = MAXLONG;
    while ((Index >= 0) && (Counts[RoundUpNum - 1] >= 0) && (Min > TempNum))
    {
      Count = Remainder / RoundUps[Index].Numerator;
      if (Remainder % RoundUps[Index].Numerator > 0) Count++;
      Counts[Index] = Count;
      Product = Count * RoundUps[Index].Numerator;
      Sum += Product;
      Remainder -= Product;
      if (Sum > TempNum)
      {
        if (Sum < Min)
          Min = Sum;
        if (Index == 0)
        {
          Product = RoundUps[Index].Numerator * Counts[Index];
          Sum -= Product;
          Remainder += Product;
          if (RoundUpNum > 1)
            Counts[Index++] = 0;
        }
        while ((Index < RoundUpNum - 1) && (Counts[Index + 1] == 0)) Index++;
        Counts[Index]--;
        Product = RoundUps[Index].Numerator;
        Sum -= Product;
        Remainder += Product;
        Index--;
      }
    }
    Num->Numerator = Min;
  }
}

/* Read in a rational decimal number from a string and change the string to
   point to the first character following the number
   Input : String: the string to read the number from
           Value: the rational number to hold the value */
void sscanRational(string* String, Rational* Value)
{
  int Exponent;
  long int Numerator = 0;
  long int Denominator = 1;
  long int Integer = 0;
  long int Fraction = 0;
  string IntegerStr = *String;
  string FractionStr;
  string StrEnd;
  while (*IntegerStr == ' ') IntegerStr++;
  FractionStr = IntegerStr;
  if ((*FractionStr == '-') || (*FractionStr == '+'))
    FractionStr++;
  while ((*FractionStr >= '0') && (*FractionStr <= '9'))
    FractionStr++;
  StrEnd = FractionStr;
  if (*FractionStr == '.')
  {
    FractionStr++;
    StrEnd++;
    while ((*StrEnd >= '0') && (*StrEnd <= '9'))
      StrEnd++;
  }
  sscanf(IntegerStr, "%ld", &Integer);
  sscanf(FractionStr, "%ld", &Fraction);
  Numerator = Integer;
  if ((Fraction > 0) && ((Exponent = StrEnd - FractionStr) < 6))
  {
    while (Exponent > 0)
    {
      Denominator *= Radix;
      Exponent--;
    }
    Numerator *= Denominator;
    Numerator += Fraction;
  }
  while (*StrEnd == ' ') StrEnd++;
  *String = StrEnd;
  Value->Numerator = Numerator;
  Value->Denominator = Denominator;
}

/* Print a rational number, that has a denominator of a power of the radix,
   into a string
   Input : String: the string to print into
           Value: the rational number
           Decimal: the number of decimal places to display */
void sprintRational(string String, Rational* Value, const int Decimal)
{
  int Exponent;
  long int Integer;
  long int Fraction;
  long int Denominator = Value->Denominator;
  long int TempDenom;
  string Str = String;
  char FormatStr[10 + 1];
  Integer = Value->Numerator / Denominator;
  Fraction = Value->Numerator % Denominator;
  if ((Fraction > (Denominator >> 1)) && (Decimal == 0))
    Integer++;
  Str += sprintf(Str, "%ld", Integer);
  if (Decimal > 0) {
    Exponent = 0;
    TempDenom = Denominator;
    while (TempDenom > 1)
    {
      TempDenom /= Radix;
      Exponent++;
    }
    while (Exponent < Decimal)
    {
      Fraction *= Radix;
      Exponent++;
    }
    while (Exponent > Decimal)
    {
      Fraction = (Fraction + (Radix >> 1)) / Radix;
      Exponent--;
    }
    sprintf(FormatStr, ".%%0%dd", Decimal);
    Str += sprintf(Str, FormatStr, Fraction);
  }
}

/* Close the output page and halt execution
   Input : ReturnCode: code to return to parent process */
void ClosePage(const int ReturnCode)
{
  if (!ListingSelf)
    printf("\n\
<P><CENTER><FONT SIZE=-2>(This page best viewed with any browser)</P>\n\
\n\
<P><A HREF=\"%s?"clListSelf"\">"SoftwareName"</A> " SoftwareVersion" "SoftwareCopyright"</CENTER></P>\n\
\n\
</BODY>\n\
</HTML>\n", ProgName);
  exit(ReturnCode);
}

/* Display an internal error and halt execution
   Input : Error: error text */
void InternalError(const string Error)
{
  printf("Internal error: %s.\n", Error);
  ClosePage(rcInternalError);
}

/* Display an error about missing input data and halt execution
   Input : Error: error text specifying the missing data */
void MissingInputError(const string Text)
{
  printf("Please, go back to the previous page and specify your %s.\n", Text);
  ClosePage(rcMissingInputData);
}

/* Display an error about invalid input data and halt execution
   Input : Error: error text specifying the invalid data */
void InvalidInputError(const string Text)
{
  printf("%s.\nPlease, go back to the previous page and correct it.\n", Text);
  ClosePage(rcInvalidInputData);
}

/* Read a line from a text file
   Input : ReadFile: the text file to read from
           Line: the string to put the data into
   Output: when false, an end-of-file was encountered before any data could
           be read */
bool ReadLine(FILE* ReadFile, string Line)
{
  char* CurLine = Line;
  int Read = false;
  while (!feof(ReadFile))
  {
    fread(CurLine, sizeof(char), 1, ReadFile);
    if (!feof(ReadFile))
    {
      Read = true;
      if (*CurLine == '\n')
        break;
      else if (*CurLine != '\r')
        CurLine++;
    }
  }
  *CurLine = '\0';
  return(Read);
}

/* Store a shipping price from the configuration data
   Input : Destination: shipping destination */
void PutShippingPrice(const int Destination)
{
  if (ShippingNum == MaxShippingNum)
    InternalError("Too many shipping prices defined in configuration");
  strcpyAllTrim(Shippings[ShippingNum].Name, ItemName);
  sscanRational(&ItemValue, &Shippings[ShippingNum].Price);
  ItemValue++;
  sscanRational(&ItemValue, &Shippings[ShippingNum].MaxValue);
  sscanf(ItemValue, ",%ld,%ld", &Shippings[ShippingNum].MaxWeight,
    &Shippings[ShippingNum].A_Weight);
  Shippings[ShippingNum].Processed = false;
  Shippings[ShippingNum++].Destination = Destination;
}

/* Load in configuration data */
void LoadConfig(void)
{
  int Index;
  int SectionMode = -1;
  char TempStr[ItemValueMaxLen + 1];
  Rational Value;
  FILE* ConfigFile;
  MaxProductNum = 0;
  MaxShippingNum = 0;
  MaxCurrencyNum = 0;
  MakeExtension(TempStr, ProgName, "cfg");
  if ((ConfigFile = fopen(TempStr, "rt")) == NULL)
    InternalError("Could not open configuration file");
  while (!feof(ConfigFile))
  {
    if (ReadLine(ConfigFile, InputData))
    {
      ItemData = InputData;
      switch (ItemData[0])
      {
        case '#': break;
        case '[':
        {
          ItemData[strlen(ItemData) - 1] = '\0';
          ItemData++;
          for (Index = 0; Index < SectionNameNum; Index++)
          {
            if (strcmp(ItemData, SectionNames[Index]) == 0)
            {
              SectionMode = Index;
              break;
            }
          }
          if (Index < SectionNameNum)
          {
            if ((SectionMode == smProducts || SectionMode == smCurrencyConversion ||
              ((SectionMode == smShippingInland || SectionMode == smShippingWorldwide)
              && MaxShippingNum == 0)) && ReadLine(ConfigFile, InputData))
            {
              sscanf(InputData, "%d", &Index);
              switch (SectionMode)
              {
                case smProducts:
                {
                  MaxProductNum = Index;
                  Products = calloc(MaxProductNum, sizeof(Product));
                  break;
                }
                case smShippingInland:
                case smShippingWorldwide:
                {
                  MaxShippingNum = Index;
                  Shippings = calloc(MaxShippingNum, sizeof(Shipping));
                  break;
                }
                case smCurrencyConversion:
                {
                  MaxCurrencyNum = Index;
                  Currencies = calloc(MaxCurrencyNum, sizeof(Currency));
                  break;
                }
              }
            }
          }
        }
        default:
        {
          ItemName = ItemData;
          if ((ItemValue = (string)strchr(ItemData, '=')) != NULL)
          {
            ItemValue++[0] = '\0';
            switch (SectionMode)
            {
              case smGeneral:
              {
                if (GeneralNum == MaxGeneralNum)
                  InternalError("Too many general data defined in configuration");
                strcpyAllTrim(GeneralData[GeneralNum].Name, ItemName);
                strcpyAllTrim(GeneralData[GeneralNum++].Value, ItemValue);
                break;
              }
              case smProducts:
              {
                if (ProductNum == MaxProductNum)
                  InternalError("Too many products defined in configuration");
                strcpyAllTrim(Products[ProductNum].Name, ItemName);
                sscanRational(&ItemValue, &Products[ProductNum].Price);
                sscanf(ItemValue, ",%ld,%s", &Products[ProductNum].Weight, TempStr);
                if (SignRational(&Products[ProductNum].Price) < 0)
                {
                  sprintf(OutputData, "Product \"%s\" is defined with a negative price in configuration", ItemName);
                  InternalError(OutputData);
                }
                Products[ProductNum++].AlwaysOnStock = (strcmp(TempStr, Yes) == 0);
                break;
              }
              case smShippingInland:
              {
                PutShippingPrice(sdInland);
                break;
              }
              case smShippingWorldwide:
              {
                PutShippingPrice(sdWorldwide);
                break;
              }
              case smPayMethodCosts:
              {
                if (PayMethodCostNum == PayMethodNum)
                  InternalError("Too many payment method costs defined in configuration");
                strcpyAllTrim(ItemName, ItemName);
                for (Index = 0; (Index < PayMethodNum) &&
                  (strcmp(ItemName, PayMethodNames[Index]) != 0); Index++);
                if (Index >= PayMethodNum)
                  InternalError("Costs defined for unknown payment method in configuration");
                PayMethodCosts[PayMethodCostNum].Type = Index;
                sscanRational(&ItemValue, &PayMethodCosts[PayMethodCostNum].Unit);
                if (SignRational(&PayMethodCosts[PayMethodCostNum].Unit) <= 0)
                  InternalError("Payment method cost defined with a non-positive unit in configuration");
                ItemValue++;
                sscanRational(&ItemValue, &PayMethodCosts[PayMethodCostNum++].Cost);
                break;
              }
              case smCurrencyConversion:
              {
                if (CurrencyNum == MaxCurrencyNum)
                  InternalError("Too many currencies defined in configuration");
                strcpyAllTrim(Currencies[CurrencyNum].Name, ItemName);
                sscanRational(&ItemValue, &Value);
                for (Index = 0; *ItemValue != '\0'; Index++)
                {
                  if (Index >= MaxPaperMoneyNum)
                  {
                    sprintf(OutputData, "Too many paper moneys defined for currency \"%s\" in configuration", ItemName);
                    InternalError(OutputData);
                  }
                  ItemValue++;
                  sscanRational(&ItemValue, &Currencies[CurrencyNum].PaperMoneys[Index]);
                }
                Currencies[CurrencyNum].PaperMoneyNum = Index;
                if (SignRational(&Value) <= 0)
                {
                  sprintf(OutputData, "Currency \"%s\" is defined with a non-positive conversion rate in configuration", ItemName);
                  InternalError(OutputData);
                }
                Currencies[CurrencyNum++].Rate = Value;
                break;
              }
              default: InternalError("Definition outside sections in configuration data");
            }
          }
        }
      }
    }
  }
  fclose(ConfigFile);
}

/* Decode a URL-encoded string
   Input : String: the URL-encoded string, which is also to contain the
                   decoded string */
void DecodeString(string String)
{
  int ReadIndex = 0;
  int WriteIndex = 0;
  int Data;
  char CurChar;
  char HexaNum[2 + 1];
  do
  {
    CurChar = String[ReadIndex++];
    switch (CurChar)
    {
      case '+':
      {
        CurChar = ' ';
        break;
      }
      case '%':
      {
        Data = -1;
        HexaNum[0] = String[ReadIndex];
        if (HexaNum[0] != '\0')
        {
          HexaNum[1] = String[ReadIndex + 1];
          HexaNum[2] = '\0';
        }
        sscanf(HexaNum, "%x", &Data);
        if (Data >= 0)
        {
          ReadIndex += 2;
          CurChar = (char)Data;
        }
        break;
      }
    }
    String[WriteIndex++] = CurChar;
  } while (CurChar != '\0');
}

/* Load item data from the form output */
void LoadItems(void)
{
  int Index;
  int ItemType;
  int ItemTypeNameLen;
  ItemNum = 0;
  memset(InputData, 0, RawDataMaxLen + 1);
  fread(InputData, sizeof(char), RawDataMaxLen, stdin);
  ItemData = InputData;
  while (ItemData[0] != '\0')
  {
    if ((NextRawData = (string)strchr(ItemData, '&')) == NULL)
      NextRawData = (string)strchr(ItemData, '\0');
    else
      NextRawData++[0] = '\0';
    ItemName = ItemData;
    if ((ItemValue = (string)strchr(ItemData, '=')) != NULL)
    {
      ItemValue++[0] = '\0';
      ItemType = -1;
      DecodeString(ItemName);
      for (Index = 0; Index < ItemTypeNameNum; Index++)
      {
        ItemTypeNameLen = strlen(ItemTypeNames[Index]);
        if (strncmp(ItemName, ItemTypeNames[Index], ItemTypeNameLen) == 0)
        {
          ItemName += ItemTypeNameLen;
          ItemType = Index;
          break;
        }
      }
      if (ItemType >= 0)
      {
        strcpyAllTrim(ItemName, ItemName);
        DecodeString(ItemValue);
        strcpyAllTrim(ItemValue, ItemValue);
        if (ItemValue[0] != '\0')
        {
          if (ItemNum == MaxItemNum)
            InternalError("Too many items defined in input form");
          Items[ItemNum].Type = ItemType;
          Items[ItemNum].Name = ItemName;
          Items[ItemNum++].Value = ItemValue;
        }
      }
    }
    ItemData = NextRawData;
  }
}

/* Retrieve general data
   Input : Name: general data name
           Mandatory: when True, the data must be present, otherwise
           execution is halted
   Output: the general data value */
string GetGeneralData(const string Name, const bool Mandatory)
{
  int Index;
  for (Index = 0; Index < GeneralNum; Index++)
  {
    if (strcmp(Name, GeneralData[Index].Name) == 0)
      return(GeneralData[Index].Value);
  }
  if (Mandatory)
  {
    sprintf(OutputData, "Missing general configuration data \"%s\"", Name);
    InternalError(OutputData);
  }
  return(NULL);
}

/* Retreive personal data and halt execution if not found
   Input : Name: personal data name
           Text: part of the error text to display if personal data has not
                 been found
   Output: the value of the personal data */
string GetPersonalData(const string Name, const string Text)
{
  int Index;
  string Value;
  for (Index = 0; Index < ItemNum; Index++)
  {
    if ((Items[Index].Type == itPersonal) && (strcmp(Name, Items[Index].Name) == 0))
    {
        Value = Items[Index].Value;
        if ((strchr(Value, '<') == NULL) && (strchr(Value, '>') == NULL))
          return(Value);
        else
        {
          sprintf(OutputData, "You have used one or more \"&lt;\" and/or \"&gt;\" characters in your %s", Text);
          InvalidInputError(OutputData);
        }
      }
  }
  MissingInputError(Text);
  return(NULL);
}

/* Print personal data
   Input : Name: personal data name
           Text: part of the error text to display if personal data has not
                 been found */
void PrintPersonalData(const string Name, const string Text)
{
  ItemData += sprintf(ItemData, "%s: %s\n", Name, GetPersonalData(Name, Text));
  BoxHeight++;
}

/* Retrieve product data and halt execution if not found
   Input : Name: product name
           Price: the rational number to contain the product price
           Weight: the integer to contain the product weight
           AlwaysOnStock: the Boolean to contain whether the product is
                          always on stock */
void GetProductData(const string Name, Rational* Price, long int* Weight,
  bool* AlwaysOnStock)
{
  int Index;
  for (Index = 0; Index < ProductNum; Index++)
  {
    if (strcmp(Name, Products[Index].Name) == 0)
    {
      *Price = Products[Index].Price;
      *Weight = Products[Index].Weight;
      *AlwaysOnStock = Products[Index].AlwaysOnStock;
      return;
    }
  }
  sprintf(OutputData, "Unknown product \"%s\" defined in input form", Name);
  InternalError(OutputData);
}

/* Retrieve shipping price data and halt execution if not found
   Input : Name: shipping price name, empty for basic price
           Price: the rational number to contain the shipping price */
void GetShippingData(const string Name, Rational* Price)
{
  bool Found = false;
  int Index;
  long int A_Weight;
  long int A_Number;
  Rational A_Price;
  Rational TotalValue;
  MakeRational(Price, 0);
  ErrorItem[0] = '\0';
  if (Name[0] != '\0')
    sprintf(ErrorItem, " \"%s\"", Name);
  for (Index = 0; Index < ShippingNum; Index++)
  {
    if ((Shippings[Index].Destination == ShippingDest) &&
      (strcmp(Name, Shippings[Index].Name) == 0))
    {
      if (SignRational(&Shippings[Index].Price) < 0)
      {
        sprintf(OutputData, "Shipping option%s is not available for your location", ErrorItem);
        InvalidInputError(OutputData);
      }
      if (Shippings[Index].Processed)
      {
        sprintf(OutputData, "Shipping option%s has been specified more than once", ErrorItem);
        InvalidInputError(OutputData);
      }
      Shippings[Index].Processed = true;
      Found = true;
      A_Price = Shippings[Index].Price;
      AddRational(&TotalValue, &TotalPrice, &A_Price);
      if (((Shippings[Index].MaxWeight < 0) ||
        (Shippings[Index].MaxWeight >= TotalWeight)) &&
        ((SignRational(&Shippings[Index].MaxValue) < 0) ||
        (CompareRational(&Shippings[Index].MaxValue, &TotalValue) >= 0)))
      {
        if ((A_Weight = Shippings[Index].A_Weight) > 0)
        {
          A_Number = TotalWeight / A_Weight;
          if (TotalWeight % A_Weight > 0)
            A_Number++;
          MultiplyRationalInt(&A_Price, &A_Price, A_Number);
        }
        *Price = A_Price;
        return;
      }
    }
  }
  if (Found)
  {
    sprintf(OutputData, "Shipping price%s not found for the shipping destination, package weight or value defined in input form", ErrorItem);
    InternalError(OutputData);
  }
  else
  {
    sprintf(OutputData, "Unknown shipping price%s defined in input form",
      ErrorItem);
    InternalError(OutputData);
  }
}

/* Retrieve currency data and halt execution if not found
   Input : Name: currency name
           Rate: the rational number to contain the conversion rate
           PaperMoneys: the pointer to contain the address of paper money
                          array
           PaperMoneyNum: the integer to contain the number of paper
                          moneys */
void GetCurrencyData(const string Name, Rational* Rate, Rational** PaperMoneys,
  int* PaperMoneyNum)
{
  int Index;
  for (Index = 0; Index < CurrencyNum; Index++)
  {
    if (strcmp(Name, Currencies[Index].Name) == 0)
    {
      *Rate = Currencies[Index].Rate;
      *PaperMoneys = Currencies[Index].PaperMoneys;
      *PaperMoneyNum = Currencies[Index].PaperMoneyNum;
      return;
    }
  }
  sprintf(OutputData, "Unknown currency \"%s\" defined in input form", Name);
  InternalError(OutputData);
}

/* Create a separator line for the header or footer of a file list
   Input: Text: the text to display in the separator line */
void MakeSeparator(const string Text)
{
  memset(OutputData, '=', FileNameMaxLen);
  OutputData[FileNameMaxLen] = '\0';
  if ((Text != NULL) && (Text[0] != '\0'))
  {
    OutputData[3] = ' ';
    strcpy(&OutputData[4], Text);
    *strend(OutputData) = ' ';
  }
}

/* List the contents of a file
   Input : FileName: the name of the file to list */
void ListFile(const string FileName)
{
  char Header[FileNameMaxLen + 1];
  FILE* ReadFile;
  if ((ReadFile = fopen(FileName, "rt")) != NULL)
  {
    sprintf(Header, "Listing file \"%s\"", FileName);
    MakeSeparator(Header);
    printf("%s\n", OutputData);
    while (!feof(ReadFile))
    {
      if (ReadLine(ReadFile, OutputData))
      printf("%s\n", OutputData);
    }
    MakeSeparator("<EOF>");
    printf("%s\n", OutputData);
    fclose(ReadFile);
  }
}

/* List the contents of a file with the same base name but different extension
   Input : Ext: the extension of the file to list */
void ListFileExt(const string Ext)
{
  char FileName[FileNameMaxLen + 1];
  MakeExtension(FileName, ProgName, Ext);
  ListFile(FileName);
}

int main(int argc, string* argv)
{
  bool AlwaysOnStock;
  bool AllAlwaysOnStock;
  bool ForeignCurrency;
  bool CoinsAllowed;
  int Index;
  int ValueIndex;
  int ProductQuantity;
  int ConvPricePrinted;
  int PayMethod;
  int PaperMoneyNum;
  long int ProductWeightEach;
  long int ProductWeight;
  long int MaxWeightAllowed;
  long int PriceUnitNum;
  string OwnCurrency;
  string ImportantNotes;
  string PayMethodStr;
  string MaxAllowedPriceStr;
  string TempStr2;
  char NumStr[10 + 1];
  char NumStr2[10 + 1];
  char TempStr[ItemValueMaxLen + 1];
  char Selection[RawDataMaxLen + 1];
  Rational ProductPriceEach;
  Rational ProductPrice;
  Rational OrigTotalPrice;
  Rational ConvTotalPrice;
  Rational ConvRate;
  Rational MaxPriceAllowed;
  Rational* PaperMoneys;
  printf("Content-Type: text/html\n");
  printf("\n\
<HTML>\n");
  ProgName = argv[0];
  if ((argc > 1) && (strcmp(argv[1], clListSelf) == 0))
  {
    ListingSelf = true;
    printf("<HEAD TITLE>"SoftwareName" "SoftwareVersion" source</TITLE></HEAD><BODY><PLAINTEXT>");
    ListFileExt("c");
    printf("\n");
    ListFileExt("cfg");
    printf("\n");
    ListFile("Makefile");
    ClosePage(rcOK);
  }
  LoadConfig();
  printf("<HEAD><TITLE>%s</TITLE></HEAD>\n\
\n\
<BODY>\n", GetGeneralData("PageTitle", true));
  LoadItems();
  ItemData = OutputData;
  ItemData += sprintf(ItemData, "<CENTER>\n\
<H3>Order details</H3>\n\
</CENTER>\n\
\n\
<FORM ACTION=\"mailto:%s?subject=%s\" METHOD=POST>\n\
\n\
<P ALIGN=\"JUSTIFY\">Please, review your order. If you wish to change\n\
something then go back to the previous page rather than directly editing the\n\
text below.</P>\n\
\n\
<CENTER>\n\
<TEXTAREA NAME=Order READONLY=\"readonly\" WRAP=HARD COLS=72 ROWS=", GetGeneralData("E-mail", true),
  GetGeneralData("OrderSubject", true));
  BoxHeightStr = ItemData;
  ItemData += sprintf(ItemData, "00>\n\n");
  BoxHeight = 1;
  PrintPersonalData("Name", "name");
  PrintPersonalData("Address", "street address");
  PrintPersonalData("E-mail", "E-mail address");
  ItemData += sprintf(ItemData, "Seller: %s\n", GetGeneralData("Seller", true));
  BoxHeight++;
  PayMethodStr = GetPersonalData("Pay method", "pay method");
  PrintPersonalData("Pay method", "pay method");
  ItemData += sprintf(ItemData, "\n");
  BoxHeight++;
  PayMethod = -1;
  for (Index = 0; Index < PayMethodNum; Index++)
  {
    if (strcmp(PayMethodStr, PayMethodNames[Index]) == 0)
    {
      PayMethod = Index;
      break;
    }
  }
  if (PayMethod < 0)
    InternalError("Unknown payment method defined in input form");
  OwnCurrency = GetGeneralData("OwnCurrency", true);
  CoinsAllowed = (strcmp(GetGeneralData("CoinsAllowed", true), Yes) == 0);
  FractionLen = (strcmp(GetGeneralData("UseCents", true), Yes) == 0)?2:0;
  MakeRational(&MaxPriceAllowed, 0);
  MaxWeightAllowed = 0;
  MaxAllowedPriceStr = GetGeneralData("MaxPriceAllowed", true);
  sscanRational(&MaxAllowedPriceStr, &MaxPriceAllowed);
  sscanf(GetGeneralData("MaxWeightAllowed", true), "%ld", &MaxWeightAllowed);
  MakeRational(&TotalPrice, 0);
  TotalWeight = 0;
  AllAlwaysOnStock = true;
  for (Index = 0; Index < ItemNum; Index++)
  {
    if (Items[Index].Type == itProduct)
    {
      ProductQuantity = 0;
      sscanf(Items[Index].Value, "%d", &ProductQuantity);
      if (ProductQuantity > 0)
      {
        GetProductData(Items[Index].Name, &ProductPriceEach,
          &ProductWeightEach, &AlwaysOnStock);
        MultiplyRationalInt(&ProductPrice, &ProductPriceEach, ProductQuantity);
        ProductWeight = ProductWeightEach * ProductQuantity;
        if (SignRational(&TotalPrice) == 0)
        {
          ItemData += sprintf(ItemData, "Order:                Qty  @ weight    @ price    Weight     Price\n%s\n",
            SeparatorStr);
          BoxHeight += 2;
        }
        sprintRational(NumStr, &ProductPriceEach, FractionLen);
        sprintRational(NumStr2, &ProductPrice, FractionLen);
        ItemData += sprintf(ItemData, "%-20s  %3d  %6ld g  %7s %s  %4ld g  %8s %s\n",
          Items[Index].Name, ProductQuantity,
          ProductWeightEach, NumStr, OwnCurrency,
          ProductWeight, NumStr2, OwnCurrency);
        BoxHeight++;
        AddRational(&TotalPrice, &TotalPrice, &ProductPrice);
        TotalWeight += ProductWeight;
        AllAlwaysOnStock &= AlwaysOnStock;
      }
    }
  }
  if (SignRational(&TotalPrice) == 0)
  {
    printf("<P ALIGN=\"JUSTIFY\">You haven't ordered anything.\nPlease, go back to the previous page and choose one or more products.</P>\n");
    ClosePage(rcEmptyOrder);
  }
  sscanf(GetGeneralData("EnvelopeWeight", true), "%ld", &ProductWeight);
  ProductWeight = (TotalWeight * ProductWeight) / 100;
  ItemData += sprintf(ItemData, "%-20s                              %4ld g\n",
    "(Envelope)", ProductWeight);
  BoxHeight++;
  TotalWeight += ProductWeight;
  if ((CompareRational(&TotalPrice, &MaxPriceAllowed) > 0) || (TotalWeight > MaxWeightAllowed))
  {
    printf("<P ALIGN=\"JUSTIFY\">You have ordered too many products.\nPlease, contact the shopkeeper in a personal E-mail.</P>\n");
    ClosePage(rcExcessOrder);
  }
  sprintRational(NumStr, &TotalPrice, FractionLen);
  ItemData += sprintf(ItemData, "%s\n%-20s                              %4ld g  %8s %s\n",
    SeparatorStr, "Products", TotalWeight, NumStr, OwnCurrency);
  BoxHeight += 2;
  ShippingDest = -1;
  for (Index = 0; (Index < ItemNum) && (ShippingDest < 0); Index++)
  {
    if ((Items[Index].Type == itShipping) && (Items[Index].Name[0] == '\0'))
    {
      for (ValueIndex = 0; ValueIndex < ShippingDestNameNum; ValueIndex++)
      {
        if (strcmp(Items[Index].Value, ShippingDestNames[ValueIndex]) == 0)
        {
          ShippingDest = ValueIndex;
          break;
        }
      }
    }
  }
  if (ShippingDest < 0)
    MissingInputError("shipping destination");
  GetShippingData("", &ProductPrice);
  sprintRational(NumStr, &ProductPrice, FractionLen);
  ItemData += sprintf(ItemData, "%-20s                                      %8s %s\n",
    "Shipping", NumStr, OwnCurrency);
  BoxHeight++;
  AddRational(&TotalPrice, &TotalPrice, &ProductPrice);
  for (Index = 0; Index < ItemNum; Index++)
  {
    if ((Items[Index].Type == itShipping) && (Items[Index].Name[0] != '\0'))
    {
      GetShippingData(Items[Index].Name, &ProductPrice);
      sprintRational(NumStr, &ProductPrice, FractionLen);
      ItemData += sprintf(ItemData, "%-20s                                      %8s %s\n",
        Items[Index].Name, NumStr, OwnCurrency);
      BoxHeight++;
      AddRational(&TotalPrice, &TotalPrice, &ProductPrice);
    }
  }
  for (Index = 0; Index < PayMethodCostNum; Index++)
  {
    if (PayMethodCosts[Index].Type == PayMethod)
    {
      NormalizeRationals(&TotalPrice, &PayMethodCosts[Index].Unit);
      PriceUnitNum = TotalPrice.Numerator / PayMethodCosts[Index].Unit.Numerator;
      if (TotalPrice.Numerator % PayMethodCosts[Index].Unit.Numerator > 0) PriceUnitNum++;
      MultiplyRationalInt(&ProductPrice, &PayMethodCosts[Index].Cost, PriceUnitNum);
      sprintRational(NumStr, &ProductPrice, FractionLen);
      ItemData += sprintf(ItemData, "%-20s                                      %8s %s\n",
        "Conversion cost", NumStr, OwnCurrency);
      BoxHeight++;
      AddRational(&TotalPrice, &TotalPrice, &ProductPrice);
    }
  }
  sprintRational(NumStr, &TotalPrice, FractionLen);
  ItemData += sprintf(ItemData, "%s\n%-20s                                      %8s %s\n",
    SeparatorStr, "Total", NumStr, OwnCurrency);
  BoxHeight += 3;
  ItemData += sprintf(ItemData, "</TEXTAREA>\n\
</CENTER>\n\
\n\
<P ALIGN=\"JUSTIFY\">Your order has the total price of %s %s", NumStr, OwnCurrency);
  TempStr[0] = '\0';
  sprintf(Selection, "<OPTION NAME=\"None\">\n");
  TempStr2 = strend(Selection);
  OrigTotalPrice = TotalPrice;
  ConvPricePrinted = 0;
  for (Index = 0; Index < ItemNum; Index++)
  {
    if (Items[Index].Type == itCurrency)
    {
      ForeignCurrency = (strcmp(Items[Index].Name, OwnCurrency) != 0);
      GetCurrencyData(Items[Index].Name, &ConvRate, &PaperMoneys, &PaperMoneyNum);
      DivideRational(&ConvTotalPrice, &OrigTotalPrice, &ConvRate);
      if (ForeignCurrency)
      {
        if (ConvPricePrinted == 0)
          ItemData += sprintf(ItemData, ", which converts to ");
        if (TempStr[0] != '\0')
        {
          if (ConvPricePrinted > 1)
            ItemData += sprintf(ItemData, ", ");
          ItemData += sprintf(ItemData, TempStr);
        }
      }
      sprintRational(NumStr, &ConvTotalPrice, CentsFractionLen);
      if (ForeignCurrency)
        sprintf(TempStr, "%s %s", NumStr, Items[Index].Name);
      if (ForeignCurrency && !CoinsAllowed && PayMethod == pmCash)
      {
        RoundUpRational(&ConvTotalPrice, PaperMoneys, PaperMoneyNum);
        sprintRational(NumStr, &ConvTotalPrice, CentsFractionLen);
      }
      TempStr2 += sprintf(TempStr2, "<OPTION NAME=\"%s %s\">%s %s\n",
        NumStr, Items[Index].Name, NumStr, Items[Index].Name);
      if (ForeignCurrency)
        ConvPricePrinted++;
    }
  }
  if (TempStr[0] != '\0')
  {
    if (ConvPricePrinted > 1)
      ItemData += sprintf(ItemData, " and ");
    ItemData += sprintf(ItemData, TempStr);
  }
  ItemData += sprintf(ItemData, ".");
  if (ConvPricePrinted > 0 && Selection[0] != '\0')
    ItemData += sprintf(ItemData, "\n\
Please, choose the currency you wish to pay with:\n\n\
<SELECT NAME=\"Total price\">\n\
%s\
</SELECT></P>", Selection);
  ItemData += sprintf(ItemData, "<P>\n\n");
  ItemData += sprintf(ItemData, "\n\
\n\
<P ALIGN=\"JUSTIFY\">If you have any comments then add them here.</P>\n\
\n\
<CENTER>\n\
<TEXTAREA NAME=Comments WRAP=HARD COLS=72 ROWS=5>\n\
</TEXTAREA>\n\
</CENTER>\n");
  if (!AllAlwaysOnStock)
  {
    ItemData += sprintf(ItemData, "\n\
<P ALIGN=\"JUSTIFY\">You have ordered one or more products that are not always\n\
on stock. Note that you may have to wait for up to two weeks until they are\n\
finished.</P>\n");
  }
  ImportantNotes = GetGeneralData("ImportantNotes", false);
  if (ImportantNotes && ImportantNotes[0] != '\0')
  {
       ItemData += sprintf(ItemData, "\n\
<H3>Important notes</H3>\n\
\n\
%s\
\n", ImportantNotes);
  }
  sprintf(ItemData, "\n\
<P ALIGN=\"JUSTIFY\">If you're satisfied then press the <B>[Send order]</B>\n\
button <U>once</U>, to have your order sent to the shopkeeper via E-mail. This\n\
will work correctly only if your browser and mailer software have been both\n\
configured properly. So, after having pressed the button, launch your mailer\n\
software and see if the order has been submitted: the addressee is \"%s\"\n\
and the subject is \"%s\". If the order has not been submitted,\n\
please, <A HREF=\"mailto:%s?subject=%s\">open a new E-mail</A>,\n\
copy & paste the order details from the upper \"window\" on this page into the\n\
E-mail body, add your comments, if any, and send the E-mail.</P>\n\
\n\
<P ALIGN=\"JUSTIFY\">Please, wait for a confirmation E-mail: that will contain\n\
information on how to pay. As we are not a company and are rather doing this\n\
as a hobby, please, be patient! However, if the confirmation E-mail doesn't\n\
arrive within <U>three weekdays</U>, submit it again or contact the shopkeeper.\n\
If you think your order might not have been submitted, see the copy & paste\n\
method above for manually submitting the order. Thank you for your order.</P>\n\
\n\
<CENTER>\n\
<INPUT TYPE=SUBMIT VALUE=\"[Send order]\">\n\
</CENTER>\n\
\n\
</FORM>\n", GetGeneralData("E-mail", true), GetGeneralData("OrderSubject", true),
  GetGeneralData("E-mail", true), GetGeneralData("OrderSubject", true));
  sprintf(NumStr, "%02d", BoxHeight);
  memcpy(BoxHeightStr, NumStr, strlen(NumStr));
  printf("%s", OutputData);
  ClosePage(rcOK);
  return(0);
}
